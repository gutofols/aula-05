// 9 - Crie uma variável booleana e atribua a ela um valor falso. 
// Em seguida, crie uma condição que verifique se a variável é falsa e, se for, 
// mude seu valor para verdadeiro.

let isTeste = false;

alert(isTeste)

if (!isTeste){
    isTeste = true
}
alert(isTeste)

//Meu deus.... eu to pegando FOGO!! hehehe
//Que venho os grandes!