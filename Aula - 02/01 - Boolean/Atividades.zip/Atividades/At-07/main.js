// 7 - Crie uma variável string e atribua a ela um valor. 
// Em seguida, crie uma condição que verifique se o valor da variável é 
// igual a "JavaScript". Se for, exiba uma mensagem no console.

let palavra = prompt("Digite uma Linguagem de programação: ")

if (palavra == "JavaScript") {
    document.write("Você acertou!")
} else {
    document.write("Você Errou!")
}