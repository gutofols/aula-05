// 1- Crie uma variável booleana e atribua a ela o valor verdadeiro. 
// Em seguida, crie uma condição que verifique se essa variável é verdadeira. 
// se for, exiba uma mensagem no console.

let isTeste = true

if (isTeste) {
    alert("A Variável é verdadeira!")
}
