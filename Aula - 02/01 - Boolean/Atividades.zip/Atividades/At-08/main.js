// 8 - Crie uma função que receba um parâmetro numérico. 
// verifique se esse número está entre 1 e 100 (inclusive). 
// Se estiver, retorne verdadeiro; 
// caso contrário, retorne falso.

function testa100(n) {
    if(n >=1 && n <= 100){
        return true
    }else {
        return false
    }
}

document.write(testa100(prompt("digite um numero: ")))

// Achoq ue to pegando a mão. Esse ja fiz sem pestanejar! :-)
