// 1.  Faça um programa que entre com três números, faça a média aritmética e mostre o
// resultado. 

let num01 = parseFloat(prompt("Digite o primeiro valor"))
let num02 = parseFloat(prompt("Digite o segundo valor"))
let num03 = parseFloat(prompt("Digite o terceiro valor"))


let med = (num01 + num02 + num03) / 3

alert(`A média é ${med}`)