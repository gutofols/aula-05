// 8 - Crie um array com os valores "azul", "vermelho", "amarelo" e "verde". 
// Remova o elemento "vermelho" do array.

let cores = ["Azul", "Vermelho", "Amarelo", "Verde"]

for (let i = 0; i < cores.length; i++) {

    if (cores[i] == "Vermelho") {
        cores.splice(i, 1)
    }
}
document.write(cores)