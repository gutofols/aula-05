// 4 - Crie um array com 5 números aleatórios e calcule a média dos valores.

let valores = [23, 45, 65, 12, 99]
let somaTotal = 0
let mediaTotal = 0

for (let index = 0; index < valores.length; index++) {
    
    somaTotal += valores[index]

}

alert(somaTotal / valores.length)
alert(somaTotal)








