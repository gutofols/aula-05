// 1 - Crie um array com os números de 1 a 10 e exiba na tela.

let numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

document.write(numeros)