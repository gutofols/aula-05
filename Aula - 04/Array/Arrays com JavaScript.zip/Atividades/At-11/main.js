// 11 - Escreva uma função chamada somarValoresPropriedade(arr, prop) que receba um array 
// de objetos e uma propriedade como parâmetros e retorne a soma dos valores da propriedade 
// em todos os objetos do array.


function somarValoresPropriedade(arr, prop){

}

let valores = [23, 45, 11, 98, 15, 23]
let prop = 5



for (let i = 0; i < valores.length; i++){
    document.write(`<br>O Valor original é ${valores[i]} . E com a adição fica `)
    document.write(+ valores[i]+prop)
}