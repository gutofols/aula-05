// 3 - Crie um array vazio e adicione os valores "banana", "maçã" e "laranja" 
// ao final do array.

let frutas = ['']

frutas.push("Banana","Maça","Laranja")

alert(frutas)