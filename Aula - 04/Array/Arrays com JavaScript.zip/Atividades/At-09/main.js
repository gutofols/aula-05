// 9 - Crie um array com os valores "casa", "carro", "bicicleta" e "avião". 
// Inverta a ordem dos elementos do array.

let palavras = ["Casa", "Carro", "Bicicleta", "Avião"]

for (let i = palavras.length -1; i >= 0; i--) {
    document.write(palavras[i])   
}

