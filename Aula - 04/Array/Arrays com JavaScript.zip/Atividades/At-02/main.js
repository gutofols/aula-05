// 2 - Crie um array com 5 cores diferentes e exiba na tela.

let cores = ["Azul", "Laranja", "Amarelo", "Preto", "Branco"]

alert(cores)